#version 330

layout (location = 0) in vec3 position;

layout (location = 1) in vec2 uv;

out vec2 td_pass_uv;

uniform mat4 ortho;

void main() {
	gl_Position = vec4(position, 1.f);

	td_pass_uv = uv;
}

