#version 330
// версия

// нулевой атрибут. Название атрибута должно совпадать с вызовом функции bindAttribute
layout (location = 0) in vec3 position;
// первый атрибут
layout (location = 1) in vec2 uv;

layout (location = 2) in float light;

layout (location = 3) in vec3 normal;

// выход на вход в фрагментный шейдер
// Приписка 'pass_' для моего удобства
out vec2 pass_uv;
out float pass_light;
out vec3 pass_normal;
out vec3 pass_position;
out vec3 vertPos;

//попытка в проекцию...
uniform mat4 projection;
uniform mat4 view;
uniform mat4 model;

// здесь не int!
void main() {
	// стандартная, типа глобальная переменная. В неё нужно записывать координату вершины
	gl_Position = projection * view * model * vec4(position, 1.f);
	pass_light = light;
	pass_uv = uv;
	pass_normal = normal;
	pass_position = vec3(model * vec4(position, 1));
	vec4 vertPos4 = model * vec4(position, 1.0);
    vertPos = vec3(vertPos4) / vertPos4.w;
}

