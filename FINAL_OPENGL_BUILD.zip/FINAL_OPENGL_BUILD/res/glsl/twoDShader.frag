#version 330
out vec4 td_color;

in vec2 td_pass_uv;

uniform sampler2D tex0;

void main() {
	td_color = texture(tex0, td_pass_uv);
}
