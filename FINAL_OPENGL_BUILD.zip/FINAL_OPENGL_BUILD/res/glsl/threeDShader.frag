#version 330
in vec2 pass_uv;
//in float pass_light;
in vec3 pass_normal;
in vec3 pass_position;
in vec3 vertPos;

out vec4 fragColor;

uniform sampler2D tex0;
uniform vec3 lightPos;
uniform vec3 viewDir;
uniform vec3 viewPos;

uniform bool flashlight;
uniform bool difused;

uniform float horizontalAngle;
uniform float verticalAngle;

const float pi = 3.14159265359;
const vec3 lightColor = vec3(1.0, 1.0, 1.0);
const float lightPower = 80.0;
const float flashlightPower = 1.0;
const float beamThickness = 25.0;
const vec3 ambientColor = vec3(0.0, 0.0, 0.0);
const vec3 diffuseColor = vec3(0.0, 0.0, 0.0);
const vec3 specColor = vec3(1.0, 1.0, 1.0);
const float shininess = 32.0;
const float screenGamma = 1; // Assume the monitor is calibrated to the sRGB color space
float flashlightAngle = (30 * pi) / 180;

void main() {
	// �������� -> gl_Color = vec4(1, 1, 1, 1);
	// ��� ������ ����� ����� �������� ���� �����

	vec3 color = texture(tex0, pass_uv).rgb;
    float alpha = texture(tex0, pass_uv)[3];

    vec3 lightDir = normalize(lightPos - pass_position);
    float theta = dot(lightDir, normalize(-viewDir));
    
    //diffuse
    vec3 ambient = 0.0 * color;

    float mileage = length(lightPos - pass_position) + 5.0;
    vec3 normal = normalize(pass_normal);

    if(flashlight){
        if(theta > cos(flashlightAngle)){
            float diff = max(dot(lightDir, normal), 0.0);
            vec3 diffuse = diff * color * flashlightPower * pow(theta, beamThickness * (1 / flashlightAngle));
            fragColor = vec4(ambient + (diffuse) * lightPower / (mileage * mileage), alpha);
        } else {
            fragColor = vec4(ambient, alpha);
        }
    } else if (difused) {
        //diffuse
        vec3 lightDir = normalize(lightPos - pass_position);
        float diff = max(dot(lightDir, normal), 0.0);
        vec3 diffuse = diff * color;
        // specular
        vec3 editViewDir = normalize(viewPos - pass_position);
        vec3 reflectDir = reflect(-lightDir, normal);
        float spec = 0.0;
        //blinn phong
        vec3 halfwayDir = normalize(lightDir + editViewDir);  
        float specAngle = max(dot(halfwayDir, normal), 0.0);
        spec = pow(specAngle, shininess);

        vec3 specular = vec3(0.1) * spec; // assuming bright white light color
        fragColor = vec4((ambient + diffuse + specular) * lightPower / 5 / (mileage * mileage), alpha);
    } else {
        fragColor = vec4(ambient * lightPower / (mileage * mileage), alpha);
    }
}