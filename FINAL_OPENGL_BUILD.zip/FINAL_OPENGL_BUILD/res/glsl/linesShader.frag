#version 330

out vec4 line_color;

void main() {
	line_color = vec4(0.2f, 0.2f, 0.2f, 0.7f);
}
